# page-mover
This is a Firefox extension that can move pages by hotkeys, like vim ('i', 'j', 'k', 'l') or a gamer ('w', 'a', 's', 'd') etc.